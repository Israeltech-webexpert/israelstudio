ISRAELSTUDIO PORTFOLIO
Open index.html in your browser or upload the folder to a static web host.
Seven pages: Home, About, Services, Portfolio, Process, FAQ, Contact.
Replace illustrative portfolio concept cards with genuine client work before describing them as delivered projects.
Verify 4+ years, 1,000+ projects and typical 1-hour reply target before publishing.
Contact form opens WhatsApp; it does not send email or store data.
Add real portrait and project screenshots when available.
Reference inspiration is not copied.
